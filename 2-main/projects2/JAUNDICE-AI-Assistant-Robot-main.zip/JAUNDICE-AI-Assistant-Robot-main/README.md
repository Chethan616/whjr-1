# JAUNDICE-AI-Assistant-Robot
An AI virtual assistant robot with Python and Arduino
