There's more to red velvet cake than just the added food coloring.
Red velvet is made with cocoa powder, vinegar and buttermilk. 
The chemical reaction between these ingredients help give the cake a deep maroon color that is often enhanced by extra food coloring.
