class Form{

constructor () {



}

display() {

    //h2 means heading sizes
    var title=createElement('h2');
    title.html("car racing game");
    title.position(130,0);
    var input = createInput("Name");
    var button = createButton('play');
    var greeting = createElement('h3');
    input.position(130,160);
    button.position(250,200);
    button.mousePressed(function() {

        input.hide();
        button.hide();
        var name = input.value();
        greeting.html("hello" + name);
        greeting.position(130,160);

    });

}

}